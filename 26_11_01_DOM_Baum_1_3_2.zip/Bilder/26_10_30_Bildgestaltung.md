# Roboterbild für die DOM-Anleitung

Stand: 30.10.2026. Erstellt und bearbeitet mit der eingebauten Bildgenerierung (`image_gen`), anschließend in die Anleitung eingebettet.

Freigegebenes Motiv: vollständig mechanischer, vereinfachter Cartoon-Roboter mit kleiner Espressotasse und dichter goldbrauner Crema. Kein Italien-Logo, keine Flagge und kein Weinglas. Das persönliche Profilfoto ist in den neuen Bedienbildern ersetzt.

Dateien: `26_10_30_Roboter_Espresso.png` und `26_10_30_Chrome_Roboter.png`. Beide liegen im Ausgabeordner und zusätzlich im Paket unter `Bilder`.

## Letzter Bildauftrag für den Roboter

Use case: precise-object-edit. Refine this exact all-metal robot drinking espresso. Keep the same recognizable robot personality, angular head, smaller amber eyes, amused confident smile, metal helmet fins, entirely robotic body, pose, white cup near the mouth, navy circular backdrop and square composition. Make the robot A LITTLE SIMPLER: reduce small panel seams, screws, intricate joints and metal texture, use larger clean shapes, bold black cartoon outlines and flat two-tone cel shading, still a mature masculine retro sci-fi cartoon robot. Keep the character recognizable, do not turn it into a cute child or a different design. Replace the relatively large cup with a smaller elegant WHITE ESPRESSO DEMITASSE: a very short concentrated espresso/ristretto portion, visibly dense rich GOLDEN-BROWN CREMA covering the surface, fine velvety crema texture with a small caramel swirl, no large dark watery liquid surface. Only a modest portion below the rim, not a full mug. One subtle steam curl. Keep articulated robot fingers gripping the small handle, face clearly visible. No flags or national colors, no emblem, no text, no logo, no wine and no human skin or hair.

## Bildauftrag zum Einsetzen in das Bedienbild

Use case: precise-object-edit / compositing. Image 1 is the edit target Chrome screenshot. Image 2 is the FINAL approved original robot avatar drinking a tiny espresso, with no flag. Replace ONLY the tiny circular human profile photograph near the top right of Image 1, between the separator and the three-dot menu, with a miniature circular rendering of Image 2. The robot metal face and small white coffee cup should be recognizable. Completely remove the original human photograph. Preserve the full original screenshot framing and its 211:225 aspect ratio, relative positions and all other Chrome UI content: puzzle-piece extension icon, three-dot menu, titlebar controls, bookmark row text 'Alle Lesezeichen', exact German label 'Entwicklermodus', and blue enabled switch. No new arrows, circles, numbers, captions or any extra robot image outside the profile circle. The avatar must have no flag and no wine. Prioritize instructional UI accuracy.
